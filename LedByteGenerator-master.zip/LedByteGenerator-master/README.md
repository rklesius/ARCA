# LED Byte Generator
Generates byte codes for sending to an LED matrix.

Simple little utility for generating byte codes for 8x8 LED matrices driven by the MAX7219/MAX7221 to use in code such as C/C++ or Energia and run on an Arduino, Raspberry Pi or micro controller such as the MSP430.
